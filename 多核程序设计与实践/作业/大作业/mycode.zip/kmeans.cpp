#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>
#include<iostream>
#include "config.h"
#include <fstream> // c++文件操作
#include <iomanip> // 设置输出格式
#define K 4
#define epsilon 0.0000001//误差
using namespace std;
/*
串行版本kmeans
数据用一个矩阵存储。矩阵的每个行向量是一个数据。
*/

/*
函数功能：随机选取k个中心
input:  需要选取的中心数k
        n数据个数
        center随机选出来的数据
*/
void kCenters(int k, int n, float* center, int dim, float* data, ofstream& out_txt_file){
    srand((unsigned)time(NULL));
    int j;
    for( int i = 0; i < k; i++ ){
        //有个bug，不能保证每次的j都是不一样的
        j = rand() % n;
        for(int o = 0; o < dim; o++){
            center[i*dim+o] = data[j*dim+o];
            //printf("%f ",center[i*dim+o]);
            out_txt_file << setprecision(4) << center[i*dim+o] << ' ';
        }
        out_txt_file << endl;
        //printf("\n");
    }
}


//计算两个向量的距离
float getDistance(float* a, float* b, int dim){
    int i;
    float sum = 0.0;
    float res = 0;

    for( int i = 0; i < dim; i++ ){
        sum += pow(a[i]-b[i],2);
    }

    res += sqrt(sum);
    return res;
}

/*
函数功能：计算数据点到每个中心的距离，选取距离最短的中心点作为其聚类中心
input: 
        center:存储中心点的数组
        dim: 数据的维度
        mydata: 当前数据点
        k: 中心点的个数
        n: 数据个数
        symbols: 存储每个点所属的中心
return:
        距离该样本点最近的中心下标
*/
void chooseCenter(float* center, int dim, float* mydata, int k, int n, int* symbols){
    
    for( int j = 0; j < n; j++ ){
        int res = 0;
        float dis = 0 ;
        float mindis = 100860;
        for(int i = 0; i < k ; i++){
            dis = getDistance( &mydata[j*dim],  &center[i*dim], dim);
            if( dis < mindis ){
                mindis = dis; 
                res = i;
            }
        }
        symbols[j] = res;
    }   
}

/*
函数功能：实现两个向量相加
Input：vector1， vector2
return： vector1 = vector1 + vector2
*/
void AddVec(float* vec1, float* vec2, int dim){
    for(int i = 0; i < dim; i++){
        vec1[i] = vec1[i] + vec2[i];
    }
}
/*
函数功能：更新聚类中心
Input: 
        mydata为数据信息
        center为中心点信息
        symbols为各数据点所属的类别标记
        k为类别个数
        n为数据个数
        dim为每个数据的维度
*/
void updateCenter(float* mydata, float* center, int* symbols, int k, int n, int dim){
    int vec_num[k];//记录第k个类有几个向量，用于最后求均值
    for(int i = 0; i < k; i++){
        vec_num[i] = 0;
        for(int j = 0; j < dim; j++){
            center[i*dim+j] = 0;
        }
    }
    for(int i = 0; i < n; i++){
        vec_num[symbols[i]] ++;
        AddVec(&center[symbols[i]*dim], &mydata[i*dim], dim);  
    }
    //算平均
    for(int i = 0; i < k; i++){
        for(int j = 0; j < dim; j++){
            center[i*dim+j] /= vec_num[i]; 
            //printf("center[%d] = %f",i*dim+j, center[i*dim+j] );
        }
        //printf("\n");
    }
  
}

/*
函数功能：向量赋值 vec1 = vec2
*/
void equ(float* vec1, float* vec2, int dim, int n){
    for(int i = 0; i < n; i++){
        for( int j = 0; j < dim; j++){
            vec1[i * dim + j] = vec2[i*dim + j];
        }
    }
}


int main(int argc, char* argv[]){
    if( argc == 3 ){
        inputPath = argv[1];
        outputPath = argv[2];
    }
    //Open the input file
    FILE* stream = fopen(inputPath, "rb");
    if(stream == NULL){
        printf("failed to open the data file %s\n", inputPath);
        return -1;
    }

    //将聚类结果保存在txt文件中
    ofstream out_txt_file;
    out_txt_file.open("./result.txt", ios::out | ios::trunc);
    out_txt_file << K << endl;

    clock_t start, end;
    float time = 0;
    
    //Read in and process the input matrix one-by-one
    int dim, n, size;
    float *data;
    loadMatrix(stream, &dim, &n, &data);
    size = n * dim;
    printf("dim = %d\n",dim);
    printf("n = %d\n",n);
    float*center;
    float* precenter;//更新前的center信息，用于比较center是否收敛
    center = (float*)malloc(K*dim*sizeof(float));
    precenter = (float*)malloc(K*dim*sizeof(float));
    int* symbols = (int*)malloc(n*sizeof(int));
    start = clock();
    //第一步：随机选取k个数据中心
    //kCenters(K, n, center, dim, data, out_txt_file);
    center[0] = data[1903748];
    center[1] = data[1903749];
    center[2] = data[74112];
    center[3] = data[74113];
    center[4] = data[1565322];
    center[5] = data[1565323];
    center[6] = data[118154];
    center[7] = data[118155];
    
    equ(precenter, center, dim, K);
    //第二步：分别计算每个数据点到每个中心的距离，选取距离最短的中心点作为其聚类中心
    chooseCenter(center, dim, data, K, n, symbols);
    //第三步：利用目前得到的聚类重新计算中心点
    updateCenter(data, center, symbols, K, n, dim);
    //第四步：重复第二步和第三步，直到收敛
    float dis = 0;
    for(int i = 0; i < K; i++){
        dis += getDistance(&precenter[i*dim],&center[i*dim],dim);
    }
    //printf("dis = %f\n",dis);
    while(dis > epsilon){
        //printf("dis = %f\n",dis);
        dis = 0;
        for(int i = 0; i < K; i++){
            dis += getDistance(&precenter[i*dim],&center[i*dim],dim);
        }
        equ(precenter, center, dim, K);
        //第二步：分别计算每个数据点到每个中心的距离，选取距离最短的中心点作为其聚类中心
        chooseCenter(center, dim, data, K, n, symbols);
        //第三步：利用目前得到的聚类重新计算中心点
        updateCenter(data, center, symbols, K, n, dim);
    }

    end = clock();
    time = (float)(end - start)/CLOCKS_PER_SEC;
    printf("Time of CPU: %f\n",time);
    //先将k个中心保存在result.txt文件中
    for(int i = 0; i < K; i++){
        out_txt_file << setprecision(4) << center[i*dim] << ' ' <<  center[i*dim+1]  << endl;
    }
    //再将数据的分类结果保存
    out_txt_file << n << endl;
    for(int i = 0; i < n; i++){
        out_txt_file << symbols[i] << endl;
    }
    out_txt_file.close();
    printf("dis = %f\n",dis);
    free(center);
    free(precenter);
    free(symbols);
    free(data);
    fclose(stream);
}