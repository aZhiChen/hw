#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main(){
    FILE *pd = NULL;
    FILE* bin = NULL;
    float a;
    //a = (int*)malloc(4096*4096);

    pd = fopen("input.txt","w");
    bin = fopen("input.bin","w");
    int dim ;
    int w ;
    printf("Please enter two intergers, one for dim and one for numbers of data.\n");
    scanf("%d%d", &dim,&w);
    fprintf(pd, "%d\n", dim);
    fprintf(pd, "%d\n", w);
    fwrite(&dim, sizeof(int),1,bin);
    fwrite(&w,sizeof(int),1,bin);
    //srand((unsigned)time(0));
    srand((unsigned)time(NULL));
    for(int i = 0; i < w; i++){
        for(int j = 0; j < dim; j++){
            a = rand() % 101+1;
            int time = 0;
            while(time < 100000) time ++;
            printf("%f ",a);
            fwrite(&a,sizeof(float),1,bin);
            fprintf(pd, "%f ", a);
        }
        fprintf(pd, "\n");
    }
    scanf("%d",&dim);
    fclose(pd);
    return 0;
}