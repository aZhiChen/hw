#include<iostream>
#include<thread>
#include<mutex>
int a ;
void Add10000() {
  for (int i=0; i<10000; i++) {
    a++;
  }
}

int main() {
  std::thread t1(Add10000);
  std::thread t2(Add10000);
  std::thread t3(Add10000);
  t1.join();
  t2.join();
  t3.join();
  std::cout << "after t1, t2 and t3, a is " << a << std::endl;
  system("pause");
  return 0;
}
