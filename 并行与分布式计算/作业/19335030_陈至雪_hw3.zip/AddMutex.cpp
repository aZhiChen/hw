#include<iostream>
#include<thread>
#include<mutex>
std::mutex mu;
int a ;
void Add(int  b) {
    mu.lock();
    a += b;
    mu.unlock();
}

int main() {
  std::thread t1(Add, 2);
  std::thread t2(Add, 1);
  std::thread t3(Add, 3);
  t1.join();
  t2.join();
  t3.join();
  std::cout << "after t1, t2 and t3, a is " << a << std::endl;
  system("pause");
  return 0;
}
