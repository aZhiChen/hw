#include<stdlib.h>
#include<stdio.h>
#include <math.h>
#include <mpi.h>
#include"Logist.h"

int main(){
    int n_samples = 0;
    int data_dim = 0;
    FILE *file;
    file = fopen("logist.data","r");
    fscanf(file, "%d", &n_samples);
    fscanf(file, "%d", &data_dim);

    int train_n = 0, test_n = 0;
    train_n = (int)(0.7 * n_samples);
    test_n = (int)(0.3 * n_samples);
    double **train_X = (double**)malloc(train_n * sizeof(double*));
    for(int i = 0; i < train_n; i++){
        train_X[i] = (double*)malloc(data_dim * sizeof(double));
    }
    double **test_X = (double**)malloc(test_n * sizeof(double*));
    for(int i = 0; i < test_n; i++){
        test_X[i] = (double*)malloc(data_dim * sizeof(double));
    }
    double* train_Y = (double*)malloc(train_n * sizeof(double));
    double* test_Y = (double*)malloc(test_n * sizeof(double));

    //Read data
    for(int i = 0; i < n_samples; i++){
        for(int j = 0; j < data_dim - 1; j++){
            if( i < train_n){
                if(!fscanf(file, "%lf", &train_X[i][j]))
                    break;
                train_X[i][data_dim-1] = 1; //for b
            }
            else if(i >= train_n){
                if(!fscanf(file, "%lf", &test_X[i-train_n][j]))
                    break; 
                test_X[i][data_dim - 1] = 1;
            }
        }
        if( i < train_n){
            if(!fscanf(file, "%lf", &train_Y[i]))
                break;
        }
        else{
            if(!fscanf(file, "%lf", &test_Y[i-train_n]))
                break;
        }
    }  
    fclose(file);

    LogistInit(data_dim);  
    LogistTrain(train_X, train_Y, train_n, 512, 0.01);
    LogistTest( test_X, test_Y, test_n, 512, data_dim);
    LogistFinilize();
    free(test_Y);
    free(train_Y);
    for(int i = 0; i < test_n; i++){
        free(test_X[i]); 
    }
    free(test_X);
    for(int i = 0; i < train_n; i++){
        free(train_X[i]); 
    }
    free(train_X);

    return 0;
}
