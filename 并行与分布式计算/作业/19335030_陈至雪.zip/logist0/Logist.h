#include <math.h>
#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#define MAX_SIZE 1000


extern double *W;
extern int data_dim;




/**********************************************************
**Logist的初始化
**初始化W
**初始化MPI
**输入：data_dim是数据维度，用于对权重矩阵W进行内存申请
***********************************************************/
void LogistInit(int input_data_dim);

/*********************************************************
**训练模型，实际上是训练W
**输入：
**X为数据特征
**Y为标签，取值为0或1
**n_samples为数据的个数
**batch_size为batch大小，默认为1024
**stride为步幅，用于更新梯度，默认为0.01
**********************************************************/
void LogistTrain(double** X, double* Y, int n_samples, int batch_size, double stride );


/*********************************************************
**测试模型
**输入：
**X为数据特征
**Y为标签，取值为0或1
**n_samples为数据的个数
**batch_size为batch大小，默认为1024
**stride为步幅，用于更新梯度，默认为0.01
**********************************************************/
void LogistTest(double** X, double* Y, int n_samples, int batch_size , int data_dim_test);


/*********************************************************
**析构函数
**********************************************************/
void LogistFinilize();

/*********************************************************
sigmoid函数
*********************************************************/
double sigmoid(double x);
