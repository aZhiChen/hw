#include"Logist.h"

double *W;
int data_dim;

double *grad;
double *part_grad;
int comm_size;
int my_rank;
int EVAL_STEP = 1000;
int MAX_STEP = 1000;

void LogistInit(int input_data_dim){
    data_dim = input_data_dim;
    MPI_Init(NULL, NULL);
    MPI_Comm_size(MPI_COMM_WORLD, &comm_size);
    MPI_Comm_rank(MPI_COMM_WORLD,&my_rank);
    W = (double*)malloc(data_dim * sizeof(double));
    grad = (double *)malloc(data_dim * sizeof(double));
    part_grad = ( double * ) malloc( data_dim * sizeof(double));
    //weight init
    if( my_rank == 0 ){
        for (int i=0;i<data_dim;i++) {
            W[i] = (double)rand() / (double)(RAND_MAX);
            //W[i]  = -100;
        }
        printf("Comm_size is %d\n",comm_size);
    }
    //bcast init weight to all machine
    MPI_Bcast(W, data_dim, MPI_DOUBLE, 0, MPI_COMM_WORLD);
}

void LogistTrain(double** X, double* Y, int n_samples, int batch_size, double stride ){
    int n_batches = (int) n_samples / batch_size;   
    int local_batch_size = (int) batch_size / comm_size;
    int batch_id = 0; 
    int start = 0;
    double part_acc = 0;
    double acc = 0;
    double **local_X = (double**)malloc(local_batch_size * sizeof(double*));
    for( int i = 0; i < local_batch_size; i++ ){
        local_X[i] = malloc(data_dim * sizeof(double));
    }
    
    double *temp_values = (double*) malloc ( local_batch_size * sizeof(double));
    double *local_Y = (double*)malloc( local_batch_size * sizeof(double) );
    int step = 0;
    
    while(step < MAX_STEP){
        while( batch_id < n_batches ){
            start = batch_id * batch_size;
            //初始化local_X 和 local_Y
        for(int i = 0; i < local_batch_size; i++){
            for(int j = 0; j < data_dim; j++)
                    local_X[i][j] = X[start + my_rank * local_batch_size + i][j];
            local_Y[i] = Y[start + my_rank * local_batch_size + i];
        }
        
       if(my_rank == 0){
            //printf("%d\n",start + my_rank * local_batch_size );
            //for(int m = 0; m < 5; m ++){
            //    printf("%lf\n",local_X[m][0]);
           // }
         }
            //WX - Y
            for(int i = 0; i < local_batch_size; i++){
                temp_values[i] = 0;
                for(int j = 0; j < data_dim; j++)
                    temp_values[i] += local_X[i][j] * W[j];
                temp_values[i] = sigmoid(temp_values[i]);

                if( step % EVAL_STEP == 0 ){
                    if( (temp_values[i] - 0.5) * (local_Y[i] - 0.5) > 0 )
                        part_acc += 1;
                }

                //用于计算梯度
                temp_values[i] -= local_Y[i];
            }

            //X.T(XW-Y)
            for( int i = 0; i < data_dim; i++ ){
                part_grad[i] = 0;
                for( int j = 0; j < local_batch_size; j++ ){
                    part_grad[i] += local_X[j][i] * temp_values[j];
                }
            }

            /*
                Compile grad and update weight using REDUCE
            */
            MPI_Reduce(part_grad, grad, data_dim, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
            //thread 0 更新
            if(my_rank == 0){
                for(int i = 0; i < data_dim; i++){
                    //printf("W[%d] = %lf\n",i,W[i]);
                    W[i] = W[i] - stride * grad[i];
                    //printf("W[%d] = %lf\n",i,W[i]);
                }
            }
            //Bcast update Weight to all threads
            MPI_Bcast(W, data_dim, MPI_DOUBLE, 0, MPI_COMM_WORLD);

            batch_id ++;
        }
        if(step % EVAL_STEP == 0){
            MPI_Reduce(&part_acc, &acc, 1, MPI_DOUBLE, MPI_SUM,  0, MPI_COMM_WORLD);
            //printf("my_rank = %d, part_acc = %lf\n",my_rank, part_acc);
            if(my_rank == 0){
                acc = acc / (n_batches * batch_size);
                printf("Step %d acc %lf\n", step, acc);
            }
        }
        step ++;
    }
    free(local_Y);
    free(temp_values);
    for( int i = 0; i < local_batch_size; i++ ){
        free(local_X[i]);
    }
    free(local_X);
}



void LogistTest(double** X, double* Y, int n_samples, int batch_size , int data_dim_test){
    if(data_dim_test != data_dim) {
        printf("data dimision error!\n");
        exit(1);
    }
    int batch_id = 0;
    int start = 0;
    double part_acc = 0;
    double acc = 0;
    int n_batches = (int) n_samples / batch_size;
    int local_batch_size = (int) batch_size / comm_size;
    double **local_X = (double**)malloc(local_batch_size * sizeof(double*));
    for( int i = 0; i < local_batch_size; i++ ){
        local_X[i] = malloc(data_dim * sizeof(double));
    }

    double *temp_values = (double*) malloc ( local_batch_size * sizeof(double));
    double *local_Y = (double*)malloc( local_batch_size * sizeof(double) );
    while(batch_id < n_batches){
        start = batch_id * batch_size;
        for(int i = 0; i < local_batch_size; i++ ){
            for(int j = 0; j < data_dim; j++){
                local_X[i][j] = X[start + my_rank * local_batch_size + i][j];
            }
            local_Y[i] = Y[start + my_rank * local_batch_size + i];
        }
        //WX - Y
        for(int i = 0; i < local_batch_size; i++){
            temp_values[i] = 0;
            for( int j = 0; j < data_dim; j++ ){
                temp_values[i] += local_X[i][j] * W[j];
            }
            temp_values[i] = sigmoid(temp_values[i]);

            if((temp_values[i]-0.5)*(local_Y[i]-0.5)>0)
                part_acc += 1;
        }
        batch_id ++;
    }
    MPI_Reduce(&part_acc, &acc, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    if(my_rank == 0){
        acc = acc / (n_batches * batch_size);
        //printf("Test mse %lf\n", acc);
    }

    free(local_Y);
    free(temp_values);
    for( int i = 0; i < local_batch_size; i++ ){
        free(local_X[i]);
    }
    free(local_X);
    return ;
}

void LogistFinilize(){
    free(part_grad);
    free(grad);
    free(W);
    MPI_Finalize();
    return;
}

double sigmoid(double x)
{
     double exp_value;
     double return_value;

     /*** Exponential calculation ***/
     exp_value = exp((double) -x);

     /*** Final sigmoid value ***/
     return_value = 1 / (1 + exp_value);

     return return_value;
}