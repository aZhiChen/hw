#include "myglwidget.h"

MyGLWidget::MyGLWidget(QWidget *parent)
	:QOpenGLWidget(parent),
	scene_id(0)
{
}

MyGLWidget::~MyGLWidget()
{

}

void MyGLWidget::initializeGL()
{
	glViewport(0, 0, width(), height());
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glDisable(GL_DEPTH_TEST);
	d = 0;
}

void MyGLWidget::paintGL()
{
	if (scene_id==0) {
		scene_0();
	}
	if (scene_id == 1) {
		scene_1();
	}
	if (scene_id == 2) {
		scene_2();
	}
	if (scene_id == 3) {
		scene_3();
	}
}

void MyGLWidget::resizeGL(int width, int height)
{
	glViewport(0, 0, width, height);
	update();
}

void MyGLWidget::keyPressEvent(QKeyEvent *e) {
	//Press 0 or 1 to switch the scene
	if (e->key() == Qt::Key_0) {
		scene_id = 0;
		update();
	}
	if (e->key() == Qt::Key_1) {
		scene_id = 1;
		update();
	}
	if (e->key() == Qt::Key_2) {
		scene_id = 2;
		update();
	}
	if (e->key() == Qt::Key_3) {
		scene_id = 3;
		update();
	}

	if (e->key() == Qt::Key_Up) {
		d += 1;
		update();
	}
	if (e->key() == Qt::Key_Down) {
		d -= 1;
		update();
	}

}

//void MyGLWidget::keyboard(unsigned char key, int& d) {
//	switch (key) {
//	case 'w':
//	{
//		d += 1;
//		update();
//	}
//	case 's':
//	{
//		d -= 1;
//		update();
//	}
//	}
//}

void MyGLWidget::scene_0()
{
	glClear(GL_COLOR_BUFFER_BIT);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0.0f, 100.0f, 0.0f, 100.0f, -1000.0f, 1000.0f);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslatef(50.0f, 50.0f, 0.0f);

	//draw a diagonal "I"
	glPushMatrix();
	glColor3f(0.839f, 0.153f, 0.157f);
	glRotatef(45.0f, 0.0f, 0.0f, 1.0f);
	glTranslatef(-2.5f, -22.5f, 0.0f);
	glBegin(GL_TRIANGLES);
	glVertex2f(0.0f, 0.0f);
	glVertex2f(5.0f, 0.0f);
	glVertex2f(0.0f, 45.0f);

	glVertex2f(5.0f, 0.0f);
	glVertex2f(0.0f, 45.0f);
	glVertex2f(5.0f, 45.0f);

	glEnd();
	glPopMatrix();
}
// GL_TRIANGLES
void MyGLWidget::scene_1()
{
	glClear(GL_COLOR_BUFFER_BIT);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0.0f, width(), 0.0f,  height(), -1000.0f, 1000.0f);
	//glFrustum(0.0f, 0.5 * width(), 0.0f, 0.5 * height(), 100.0f, 1000.0f);
	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(0.0, 0.0, 1.0 * d, 0.0, 0.0, 0.0, 0.0, 1.0,0.0);
	//gluLookAt(0.0, d, 2.0 * d, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	glTranslatef(0.5 * width(), 0.5 * height(), 0.0f);
	
    //your implementation here, maybe you should write several glBegin

	glPushMatrix();
	//your implementation
	//C
	glColor3f(1.0f, 0.0f, 0.0f);
	glTranslatef(-217.5f, -67.5f, 0.0f);
	glBegin(GL_TRIANGLES);
	glVertex2f(0.0f, 0.0f);
	glVertex2f(0.0f, 135.0f);
	glVertex2f(15.0f, 120.0f);

	glVertex2f(15.0f, 120.0f);
	glVertex2f(15.0f, 15.0f);
	glVertex2f(0.0f, 0.0f);

	glVertex2f(15.0f, 15.0f);
	glVertex2f(0.0f, 0.0f);
	glVertex2f(105.0f, 0.0f);

	glVertex2f(105.0f, 0.0f);
	glVertex2f(105.0f, 15.0f);
	glVertex2f(15.0f, 15.0f);

	glVertex2f(15.0f, 120.0f);
	glVertex2f(0.0f, 135.0f);
	glVertex2f(105.0f, 135.0f);

	glVertex2f(15.0f, 120.0f);
	glVertex2f(105.0f, 120.0f);
	glVertex2f(105.0f, 135.0f);
	glEnd();
	glPopMatrix();

	//Z
	glPushMatrix();
	glColor3f(1.0f, 0.0f, 0.0f);
	glTranslatef(-67.5f, -67.5f, 0.0f);
	glBegin(GL_TRIANGLES);
	glVertex2f(0.0f, 0.0f);
	glVertex2f(105.0f, 135.0f);
	glVertex2f(0.0f, 15.0f);

	glVertex2f(105.0f, 120.0f);
	glVertex2f(105.0f, 135.0f);
	glVertex2f(0.0f, 0.0f);

	glVertex2f(105.0f, 15.0f);
	glVertex2f(0.0f, 0.0f);
	glVertex2f(105.0f, 0.0f);

	glVertex2f(0.0f, 0.0f);
	glVertex2f(105.0f, 15.0f);
	glVertex2f(0.0f, 15.0f);

	glVertex2f(0.0f, 120.0f);
	glVertex2f(0.0f, 135.0f);
	glVertex2f(105.0f, 120.0f);

	glVertex2f(0.0f, 135.0f);
	glVertex2f(105.0f, 120.0f);
	glVertex2f(105.0f, 135.0f);
	glEnd();
	glPopMatrix();

	
	//X
	glPushMatrix();
	glColor3f(1.0f, 0.0f, 0.0f);
	glTranslatef(82.5f, -67.5f, 0.0f);
	glBegin(GL_TRIANGLES);
	glVertex2f(0.0f, 0.0f);
	glVertex2f(105.0f, 135.0f);
	glVertex2f(15.0f, 0.0f);

	glVertex2f(105.0f, 135.0f);
	glVertex2f(90.0f, 135.0f);
	glVertex2f(0.0f, 0.0f);

	glVertex2f(0.0f, 135.0f);
	glVertex2f(90.0f, 0.0f);
	glVertex2f(105.0f, 0.0f);

	glVertex2f(105.0f, 0.0f);
	glVertex2f(0.0f, 135.0f);
	glVertex2f(15.0f, 135.0f);

	glEnd();
	glPopMatrix();


}


// GL_TRIANGLE_STRIP
void MyGLWidget::scene_2()
{
	glClear(GL_COLOR_BUFFER_BIT);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	//glOrtho(0.0f, width(), 0.0f, height(), -1000.0f, 1000.0f);
	glFrustum(0.0f, 0.5 * width(), 0.0f, 0.5 * height(), 100.0f, 1000.0f);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(0.0, 0.0, 1.0 * d, 0.0, 0.0, 0.0, 0.0, 1.0,0.0);
	//gluLookAt(0.0, d, 2.0 * d, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	glTranslatef(0.5 * width(), 0.5 * height(), 0.0f);

	//glTranslatef(100.0f, 100.0f, 0.0f);
	//your implementation here, maybe you should write several glBegin

	glPushMatrix();
	//your implementation
	//C
	glColor3f(0.0f, 1.0f, 0.0f);
	glTranslatef(-217.5f, -67.5f, 0.0f);
	glBegin(GL_TRIANGLE_STRIP);
	glVertex2f(105.0f, 135.0f);
	glVertex2f(105.0f, 120.0f);
	glVertex2f(0.0f, 135.0f);
	glVertex2f(15.0f, 120.0f);
	glVertex2f(0.0f, 0.0f);
	glVertex2f(15.0f, 15.0f);
	glVertex2f(105.0f, 0.0f);
	glVertex2f(105.0f, 15.0f);
	glEnd();
	glPopMatrix();

	//Z
	glPushMatrix();
	glColor3f(0.0f, 1.0f, 0.0f);
	glTranslatef(-67.5f, -67.5f, 0.0f);
	glBegin(GL_TRIANGLE_STRIP);
	glVertex2f(0.0f, 135.0f);
	glVertex2f(0.0f, 120.0f);
	glVertex2f(105.0f, 135.0f);
	glVertex2f(105.0f, 120.0f);
	glVertex2f(0.0f, 15.0f);
	glVertex2f(0.0f, 0.0f);
	glVertex2f(105.0f, 15.0f);
	glVertex2f(105.0f, 0.0f);

	glEnd();
	glPopMatrix();


	//X
	glPushMatrix();
	glColor3f(0.0f, 1.0f, 0.0f);
	glTranslatef(82.5f, -67.5f, 0.0f);
	glBegin(GL_TRIANGLE_STRIP);
	glVertex2f(0.0f, 0.0f);
	glVertex2f(90.0f, 135.0f);
	glVertex2f(15.0f, 0.0f);
	glVertex2f(105.0f, 135.0f);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.0f, 1.0f, 0.0f);
	glTranslatef(82.5f, -67.5f, 0.0f);
	glBegin(GL_TRIANGLE_STRIP);
	glVertex2f(90.0f, 0.0f);
	glVertex2f(105.0f, 0.0f);
	glVertex2f(0.0f, 135.0f);
	glVertex2f(15.0f, 135.0f);
	glEnd();
	glPopMatrix();


}


//GL_QUAD_STRIP
void MyGLWidget::scene_3()
{
	glClear(GL_COLOR_BUFFER_BIT);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0.0f, width(), 0.0f, height(), -1000.0f, 1000.0f);
	//glFrustum(0.0f, 0.5 * width(), 0.0f, 0.5 * height(), 100.0f, 1000.0f);
	//glOrtho(0.0f, 200.0f, 0.0f, 200.0f, -1000.0f, 1000.0f);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	//gluLookAt(0.0, 0.0, 1.0 * d, 0.0, 0.0, 0.0, 0.0, 1.0,0.0);
	gluLookAt(0.0, d, 2.0 * d, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	glTranslatef(0.5 * width(), 0.5 * height(), 0.0f);

	//glTranslatef(100.0f, 100.0f, 0.0f);
	//your implementation here, maybe you should write several glBegin

	glPushMatrix();
	//your implementation
	//C
	glColor3f(0.0f, 0.0f, 1.0f);
	glTranslatef(-217.5f, -67.5f, 0.0f);
	glBegin(GL_QUAD_STRIP);
	glVertex2f(105.0f, 135.0f);
	glVertex2f(105.0f, 120.0f);
	glVertex2f(0.0f, 135.0f);
	glVertex2f(15.0f, 120.0f);
	glVertex2f(0.0f, 0.0f);
	glVertex2f(15.0f, 15.0f);
	glVertex2f(105.0f, 0.0f);
	glVertex2f(105.0f, 15.0f);
	glEnd();
	glPopMatrix();

	//Z
	glPushMatrix();
	glColor3f(0.0f, 0.0f, 1.0f);
	glTranslatef(-67.5f, -67.5f, 0.0f);
	glBegin(GL_QUAD_STRIP);
	glVertex2f(0.0f, 135.0f);
	glVertex2f(0.0f, 120.0f);
	glVertex2f(105.0f, 135.0f);
	glVertex2f(105.0f, 120.0f);
	glVertex2f(0.0f, 15.0f);
	glVertex2f(0.0f, 0.0f);
	glVertex2f(105.0f, 15.0f);
	glVertex2f(105.0f, 0.0f);
	glEnd();
	glPopMatrix();


	//X
	glPushMatrix();
	glColor3f(0.0f, 0.0f, 1.0f);
	glTranslatef(82.5f, -67.5f, 0.0f);
	glBegin(GL_QUAD_STRIP);
	glVertex2f(0.0f, 0.0f);
	glVertex2f(15.0f, 0.0f);
	glVertex2f(90.0f, 135.0f);
	glVertex2f(105.0f, 135.0f);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.0f, 0.0f, 1.0f);
	glTranslatef(82.5f, -67.5f, 0.0f);
	glBegin(GL_QUAD_STRIP);
	glVertex2f(90.0f, 0.0f);
	glVertex2f(105.0f, 0.0f);
	glVertex2f(0.0f, 135.0f);
	glVertex2f(15.0f, 135.0f);
	glEnd();
	glPopMatrix();

}
