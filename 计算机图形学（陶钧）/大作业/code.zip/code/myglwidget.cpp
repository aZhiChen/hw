﻿#include "myglwidget.h"
#include <time.h>
#include <windows.h>
#include "render_text.h"
#include "texture.h"

#define BMP_Header_Length 54

#define BITMAP_ID 0x4D42   


/*###################################################
##  函数: MyGLWidget
##  函数描述： MyGLWidget类的构造函数，实例化定时器timer
##  参数描述：
##  parent: MyGLWidget的父对象
#####################################################*/

MyGLWidget::MyGLWidget(QWidget *parent)
	:QOpenGLWidget(parent)
{
	k = 0;
	st->hold = -1;
	st->gox = 0;
	st->goy = 0;
	st->blood = 3;
	st->v = 20;
	st->death = 0;
	st->score = 0;

	cnt[0] = 1;
	cnt[1] = 1;
	cnt[2] = 1;
	cnt[3] = 1;
	cnt[4] = 1;

	randxy(ox[0], 25, 10);
	randxy(oy[0], -1700, -1800);
	randxy(ox[1], 225, 175);
	randxy(oy[1], -600, -700);
	randxy(ox[2], -375, -475);
	randxy(oy[2], -850, -900);
	randxy(ox[3], 525, 425);
	randxy(oy[3], -1000, -1250);
	randxy(ox[4], -175, -275);
	randxy(oy[4], -1300, -1550);
	otx[0] = 0;
	oty[0] = 0;
	otx[1] = 0;
	oty[1] = 0;
	otx[2] = 0;
	oty[2] = 0;
	otx[3] = 0;
	oty[3] = 0;
	otx[4] = 0;
	oty[4] = 0;
	ty = 9.0f;

	xrange[0][0] = 25;
	xrange[0][1] = 10;
	yrange[0][0] = -1800;
	yrange[0][1] = -2000;
	xrange[1][0] = 225;
	xrange[1][1] = 175;
	yrange[1][0] = -600;
	yrange[1][1] = -700;
	xrange[2][0] = -375;
	xrange[2][1] = -475;
	yrange[2][0] = -850;
	yrange[2][1] = -900;
	xrange[3][0] = 325;
	xrange[3][1] = 255;
	yrange[3][0] = -1300;
	yrange[3][1] = -1350;
	xrange[4][0] = -175;
	xrange[4][1] = -275;
	yrange[4][0] = -1550;
	yrange[4][1] = -1750;

	Load = true;
	Collision = false;
	
	x = -10.0f;
	y = 0.0f;
	z = 10.0f;
	win_width = 1000;
	win_height = 667;
	stand = true;
	right_hand = true;
	timer = new QTimer(this); // 实例化一个定时器
}

void MyGLWidget::randxy(int& num, int max, int min) {
	//srand((unsigned)time(NULL));
	num = rand() % (max - min);
	num += min;
	//printf("num: %d\n", num);
}

//障碍物碰撞检测
bool MyGLWidget::isCollision() {
	GLfloat zh1_width = 1524;
	GLfloat zh1_height = 828;
	float dis[5];
	//printf("y: %f\n",y);
	//printf("s1x: %f\n", -ox[1] - zh1_width / 2);
	//printf("oy[1]: %f\n", oy[1]);
	//printf("s1y: %f\n", oy[2] + y + oty[2] );
	for (int i = 0; i < 5; i++) {
		dis[i] = (pow(-ox[i] + x + otx[i], 2) + pow(oy[i] + y + oty[i], 2));
	}
	//disx < 100, disy < 80 ( 100 * 100 + 80 * 80 = 16400)
	if (dis[0] < 7200 || dis[1] < 7200 || dis[2] < 7200 || dis[3] < 7200 || dis[4] < 7200)
		return true;
	else return false;
}


/*###################################################
##  函数: ~MyGLWidget
##  函数描述： ~MyGLWidget类的析构函数，删除timer
##  参数描述： 无
#####################################################*/
MyGLWidget::~MyGLWidget()
{
	delete this->timer;
}


/*###################################################
##  函数: initializeGL
##  函数描述： 初始化绘图参数，如视窗大小、背景色等
##  参数描述： 无
#####################################################*/
void MyGLWidget::initializeGL()
{
	glViewport(0, 0, width(), height());  
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f); 
	glDisable(GL_DEPTH_TEST);             
}

void MyGLWidget::LoadAllTexture() {
	/*
	0 背景
	1~6 人物
	7~10 怪物
	11~15 障碍物
	16~19 血量
	*/
	int mw_width = 100;
	int mw_height = 136;
	if (Load == true) {
		//printf("Load Texture\n");
		//背景
		Texture[0] = LoadTexture("picture\\background\\background.bmp", win_width, win_height);
		//人物
		Texture[1] = LoadTexture("picture\\role\\r2.bmp", mw_width, mw_height);
		Texture[2] = LoadTexture("picture\\role\\r1.bmp", mw_width, mw_height);
		Texture[3] = LoadTexture("picture\\role\\0.bmp", 180, mw_height);
		Texture[4] = LoadTexture("picture\\role\\l1.bmp", mw_width, mw_height);
		Texture[5] = LoadTexture("picture\\role\\l2.bmp", mw_width, mw_height);
		Texture[6] = LoadTexture("picture\\role\\1.bmp", mw_width, mw_height);
		//怪物
		Texture[7] = LoadTexture("picture\\monster\\1.bmp", 200,200);
		Texture[8] = LoadTexture("picture\\monster\\2.bmp", 200, 200);
		Texture[9] = LoadTexture("picture\\monster\\3.bmp", 200, 200);
		Texture[10] = LoadTexture("picture\\monster\\4.bmp", 200, 200);
		//障碍物
		Texture[11] = LoadTexture("picture\\obstacle\\s0.bmp", 1524, 828);
		Texture[12] = LoadTexture("picture\\obstacle\\s1.bmp", 1524, 828);
		Texture[13] = LoadTexture("picture\\obstacle\\s2.bmp", 1524, 828);
		Texture[14] = LoadTexture("picture\\obstacle\\s3.bmp", 1524, 828);
		Texture[15] = LoadTexture("picture\\obstacle\\s4.bmp", 1524, 828);
		//血量
		Texture[16] = LoadTexture("picture\\blood\\blood0.bmp", 220, 90);
		Texture[17] = LoadTexture("picture\\blood\\blood1.bmp", 220, 90);
		Texture[18] = LoadTexture("picture\\blood\\blood2.bmp", 220, 90);
		Texture[19] = LoadTexture("picture\\blood\\blood3.bmp", 220, 90);

		Texture[20] = LoadTexture("picture\\background\\begin.bmp", 1524,828);
		Texture[21] = LoadTexture("picture\\background\\sta.bmp", 800,216);
		//结束
		Texture[22] = LoadTexture("picture\\background\\end1.bmp", 2228,972);
		//失败头像
		Texture[23] = LoadTexture("picture\\blood\\fail.bmp", 100,100);
		//加速标志
		Texture[24] = LoadTexture("picture\\background\\v.bmp", 300,171);

		Load = false;
	}
}


void MyGLWidget::drawBackground() {
	GLfloat zoom = 300.f;
	glColor3f(1.f, 1.f, 1.f);
	glDisable(GL_DEPTH_TEST);//关闭深度测试
	GLuint texture;
	texture = Texture[0];
	//texture = LoadTexture("D:\\VS_project\\ww\\role\\snow1.bmp", win_width, win_height);    //加载图片
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texture);
	GLfloat my_x = -200.f * (zoom * win_width / win_height);
	GLfloat my_y = -200.f * zoom;
	for (int i = 0; i < 200; i++) {
		for (int j = 0; j < 200; j++) {
			glBegin(GL_QUADS);      //将图片四个角的位置设置为正交窗口后裁剪面的四个角；
			glTexCoord2d(0.0, 0.0); glVertex3d(my_x + i * 2 * zoom * win_width / win_height, my_y + j * 2 * zoom, -300);
			glTexCoord2d(1.0, 0.0); glVertex3d(my_x + (i + 1) * 2 * zoom * win_width / win_height, my_y + j * 2 * zoom, -300);
			glTexCoord2d(1.0, 1.0); glVertex3d(my_x + (i + 1) * 2 * zoom * win_width / win_height, my_y + (j + 1) * 2 * zoom, -300);
			glTexCoord2d(0.0, 1.0); glVertex3d(my_x + i * 2 * zoom * win_width / win_height, my_y + (j + 1) * 2 * zoom, -300);
			glEnd();
			
		}
	}

	glDisable(GL_TEXTURE_2D);
	glEnable(GL_DEPTH_TEST);   //开启深度测试；

}


void MyGLWidget::drawBegin() {
	glColor3f(1.f, 1.f, 1.f);
	glDisable(GL_DEPTH_TEST);//关闭深度测试
	GLuint texture;
	GLfloat zh1_width = 1524;
	GLfloat zh1_height = 828;
	glEnable(GL_ALPHA_TEST);//透明部分测试
	glAlphaFunc(GL_GREATER, 0.5);

	texture = Texture[20];
	glBindTexture(GL_TEXTURE_2D, texture);
	texture_colorkey(245, 245, 245, 20);
	glEnable(GL_TEXTURE_2D);
	glBegin(GL_QUADS);      //将图片四个角的位置设置为正交窗口后裁剪面的四个角；
	glTexCoord2d(0.0, 0.0); glVertex3d(-zh1_width / 2, -zh1_height / 2 - 150, -300);
	glTexCoord2d(1.0, 0.0); glVertex3d(zh1_width / 2, -zh1_height / 2 - 150, -300);
	glTexCoord2d(1.0, 1.0); glVertex3d(zh1_width / 2, +zh1_height / 2 - 150, -300);
	glTexCoord2d(0.0, 1.0); glVertex3d(-zh1_width / 2, +zh1_height / 2 - 150, -300);
	glEnd();
	glDisable(GL_TEXTURE_2D);

	glDisable(GL_ALPHA_TEST);
	glEnable(GL_DEPTH_TEST);   //开启深度测试；
}

void MyGLWidget::drawRole() {
	GLfloat zoom = 50.f;
	glColor3f(1.f, 1.f, 1.f);
	glDisable(GL_DEPTH_TEST);//关闭深度测试
	GLuint texture;
	//加载图片
	int mw_width = 100;
	int mw_height = 136;
	if (st->gox == -4) {
		//texture = LoadTexture("D:\\VS_project\\ww\\role\\r2.bmp", mw_width, mw_height);
		texture = Texture[1];
	}
	else if (st->gox == -2) {
		//texture = LoadTexture("D:\\VS_project\\ww\\role\\r1.bmp", mw_width, mw_height);
		texture = Texture[2];
	}
	else if ((st->gox == 0 && st->goy == 0) || st->hold == -1) {
		mw_width = 180;
		//texture = LoadTexture("D:\\VS_project\\ww\\role\\0.bmp", mw_width, mw_height);
		texture = Texture[3];
	}
	else if (st->gox == 2) {
		//texture = LoadTexture("D:\\VS_project\\ww\\role\\l1.bmp", mw_width, mw_height);
		texture = Texture[4];
	}
	else if (st->gox == 4) {
		//texture = LoadTexture("D:\\VS_project\\ww\\role\\l2.bmp", mw_width, mw_height);
		texture = Texture[5];
	}
	else {
		//texture = LoadTexture("D:\\VS_project\\ww\\role\\1.bmp", mw_width, mw_height);
		texture = Texture[6];
	}
	glEnable(GL_ALPHA_TEST);//透明部分测试
	glAlphaFunc(GL_GREATER, 0.5);
	glBindTexture(GL_TEXTURE_2D, texture);
	texture_colorkey(236, 236, 236, 5);
	//if(st->fail==1)  texture_colorkey(243, 240, 234, 5);
	glEnable(GL_TEXTURE_2D);
	glBegin(GL_QUADS);      //将图片四个角的位置设置为正交窗口后裁剪面的四个角；
	glTexCoord2d(0.0, 0.0); glVertex3d(-mw_width / 2 - 6, -mw_height / 2, -300);
	glTexCoord2d(1.0, 0.0); glVertex3d(mw_width / 2 - 6, -mw_height / 2, -300);
	glTexCoord2d(1.0, 1.0); glVertex3d(mw_width / 2 - 6,  mw_height / 2, -300);
	glTexCoord2d(0.0, 1.0); glVertex3d(-mw_width / 2 - 6, mw_height / 2, -300);
	glEnd();

	glDisable(GL_TEXTURE_2D);
	glDisable(GL_ALPHA_TEST);
	glEnable(GL_DEPTH_TEST);   //开启深度测试；
}

void MyGLWidget::Blood() {
	GLfloat zoom = 50.f;
	glColor3f(1.f, 1.f, 1.f);
	glDisable(GL_DEPTH_TEST);//关闭深度测试
	GLuint texture;
	//加载图片
	int mw_width = 220;
	int mw_height = 90;
	if (st->blood == 3) {
		texture = Texture[19];
	}
	else if (st->blood == 2) {
		texture = Texture[18];
	}
	else if (st->blood == 1) {
		texture = Texture[17];
	}
	else if (st->blood == 0) {
		texture = Texture[16];
	}

	glEnable(GL_ALPHA_TEST);//透明部分测试
	glAlphaFunc(GL_GREATER, 0.5);
	glBindTexture(GL_TEXTURE_2D, texture);
	texture_colorkey(243, 243, 243, 5);
	glEnable(GL_TEXTURE_2D);
	glBegin(GL_QUADS);      //将图片四个角的位置设置为正交窗口后裁剪面的四个角；
	glTexCoord2d(0.0, 0.0); glVertex3d(-mw_width / 2 - 6, -mw_height / 2, -300);
	glTexCoord2d(1.0, 0.0); glVertex3d(mw_width / 2 - 6, -mw_height / 2, -300);
	glTexCoord2d(1.0, 1.0); glVertex3d(mw_width / 2 - 6, mw_height / 2, -300);
	glTexCoord2d(0.0, 1.0); glVertex3d(-mw_width / 2 - 6, mw_height / 2, -300);
	glEnd();

	glDisable(GL_TEXTURE_2D);
	glDisable(GL_ALPHA_TEST);
	glEnable(GL_DEPTH_TEST);   //开启深度测试；
}


int max(int a, int b) {
	return  a > b ? a : b;
}
//显示分数
void MyGLWidget::showsc() {
	glDisable(GL_TEXTURE_2D);
	glColor3f(1.0f, 0.0f, 0.0f);
	glRasterPos2f(0, 10);
	//printf("%d %d\n", ww, wh);
	selectFont(max(ww / 20, wh / 16), ANSI_CHARSET, "Comic Sans MS");
	drawCNString("Score:");

	glRasterPos2f(30.0, -30.0);
	selectFont(max(ww / 20, wh / 16), ANSI_CHARSET, "Comic Sans MS");
	char* temp = to_char(st->score);
	drawCNString(temp);
	delete temp;

	glEnable(GL_TEXTURE_2D);

}

//开始界面
void MyGLWidget::stagame() {
	GLfloat zoom = 50.f;
	glColor3f(1.f, 1.f, 1.f);
	glDisable(GL_DEPTH_TEST);//关闭深度测试
	GLuint texture;
	//加载图片
	int mw_width = 800;
	int mw_height = 216;

	texture = Texture[21];

	glEnable(GL_ALPHA_TEST);//透明部分测试
	glAlphaFunc(GL_GREATER, 0.5);
	glBindTexture(GL_TEXTURE_2D, texture);
	texture_colorkey(255, 255, 255, 5);
	glEnable(GL_TEXTURE_2D);
	glBegin(GL_QUADS);      //将图片四个角的位置设置为正交窗口后裁剪面的四个角；
	glTexCoord2d(0.0, 0.0); glVertex3d(-mw_width / 2 + 50, -mw_height / 2 + 250, -300);
	glTexCoord2d(1.0, 0.0); glVertex3d(mw_width / 2 + 50, -mw_height / 2 + 250, -300);
	glTexCoord2d(1.0, 1.0); glVertex3d(mw_width / 2 + 50, mw_height / 2 + 250, -300);
	glTexCoord2d(0.0, 1.0); glVertex3d(-mw_width / 2 + 50, mw_height / 2 + 250, -300);
	glEnd();

	glDisable(GL_TEXTURE_2D);
	glDisable(GL_ALPHA_TEST);
	glEnable(GL_DEPTH_TEST);   //开启深度测试；
}

//结束界面
void MyGLWidget::endgame() {
	GLfloat zoom = 50.f;
	glColor3f(1.f, 1.f, 1.f);
	glDisable(GL_DEPTH_TEST);//关闭深度测试
	GLuint texture;
	//加载图片
	int mw_width = 2228;
	int mw_height =972;

	texture = Texture[22];

	glEnable(GL_ALPHA_TEST);//透明部分测试
	glAlphaFunc(GL_GREATER, 0.5);
	glBindTexture(GL_TEXTURE_2D, texture);
	texture_colorkey(181, 184, 182, 5);
	glEnable(GL_TEXTURE_2D);
	glBegin(GL_QUADS);      //将图片四个角的位置设置为正交窗口后裁剪面的四个角；
	glTexCoord2d(0.0, 0.0); glVertex3d(-mw_width / 2 - 40, -mw_height / 2 + 40, -300);
	glTexCoord2d(1.0, 0.0); glVertex3d(mw_width / 2 - 40, -mw_height / 2 + 40, -300);
	glTexCoord2d(1.0, 1.0); glVertex3d(mw_width / 2 - 40, mw_height / 2 + 40, -300);
	glTexCoord2d(0.0, 1.0); glVertex3d(-mw_width / 2 - 40, mw_height / 2 + 40, -300);
	glEnd();

	glDisable(GL_TEXTURE_2D);
	glDisable(GL_ALPHA_TEST);
	glEnable(GL_DEPTH_TEST);   //开启深度测试；
}

//显示失败笑脸
void MyGLWidget::drawFail() {
	GLfloat zoom = 50.f;
	glColor3f(1.f, 1.f, 1.f);
	glDisable(GL_DEPTH_TEST);//关闭深度测试
	GLuint texture;
	//加载图片
	int mw_width = 100;
	int mw_height = 100;
	texture = Texture[23];
	glEnable(GL_ALPHA_TEST);//透明部分测试
	glAlphaFunc(GL_GREATER, 0.5);
	glBindTexture(GL_TEXTURE_2D, texture);
	texture_colorkey(255,255,255, 5);
	//if(st->fail==1)  texture_colorkey(243, 240, 234, 5);
	glEnable(GL_TEXTURE_2D);
	glBegin(GL_QUADS);      //将图片四个角的位置设置为正交窗口后裁剪面的四个角；
	glTexCoord2d(0.0, 0.0); glVertex3d(-mw_width / 2 - 6, -mw_height / 2, -300);
	glTexCoord2d(1.0, 0.0); glVertex3d(mw_width / 2 - 6, -mw_height / 2, -300);
	glTexCoord2d(1.0, 1.0); glVertex3d(mw_width / 2 - 6, mw_height / 2, -300);
	glTexCoord2d(0.0, 1.0); glVertex3d(-mw_width / 2 - 6, mw_height / 2, -300);
	glEnd();

	glDisable(GL_TEXTURE_2D);
	glDisable(GL_ALPHA_TEST);
	glEnable(GL_DEPTH_TEST);   //开启深度测试；
}

//显示加速
void MyGLWidget::drawSpeed() {
	GLfloat zoom = 50.f;
	glColor3f(1.f, 1.f, 1.f);
	glDisable(GL_DEPTH_TEST);//关闭深度测试
	GLuint texture;
	//加载图片
	int mw_width = 300;
	int mw_height = 171;
	texture = Texture[24];
	glEnable(GL_ALPHA_TEST);//透明部分测试
	glAlphaFunc(GL_GREATER, 0.5);
	glBindTexture(GL_TEXTURE_2D, texture);
	texture_colorkey(255,255,255, 5);
	//if(st->fail==1)  texture_colorkey(243, 240, 234, 5);
	glEnable(GL_TEXTURE_2D);
	glBegin(GL_QUADS);      //将图片四个角的位置设置为正交窗口后裁剪面的四个角；
	glTexCoord2d(0.0, 0.0); glVertex3d(-mw_width / 2 - 6, -mw_height / 2, -300);
	glTexCoord2d(1.0, 0.0); glVertex3d(mw_width / 2 - 6, -mw_height / 2, -300);
	glTexCoord2d(1.0, 1.0); glVertex3d(mw_width / 2 - 6, mw_height / 2, -300);
	glTexCoord2d(0.0, 1.0); glVertex3d(-mw_width / 2 - 6, mw_height / 2, -300);
	glEnd();

	glDisable(GL_TEXTURE_2D);
	glDisable(GL_ALPHA_TEST);
	glEnable(GL_DEPTH_TEST);   //开启深度测试；
}


/*###################################################
##  函数: drawMonster
##  函数描述： 绘制怪物
##  参数描述： 无
#####################################################*/
void MyGLWidget::drawMonster() {
	GLfloat zoom = 1.f;
	glColor3f(1.f, 1.f, 1.f);
	glDisable(GL_DEPTH_TEST);//关闭深度测试
	GLuint texture;
	int mw_width = 200;
	int mw_height = 200;
	if (monster->i == 0) texture = Texture[7];
	else if (monster->i == 1) texture = Texture[8];
	else if (monster->i == 2) texture = Texture[9];
	else if (monster->i == 3) texture = Texture[10];
	monster->i = monster->i + 1;
	if (monster->i == 4) monster->i /= 4;
	Sleep(100);
	//printf("%d\n", c);
	glEnable(GL_ALPHA_TEST);//透明部分测试
	glAlphaFunc(GL_GREATER, 0.5);
	glBindTexture(GL_TEXTURE_2D, texture);
	texture_colorkey(255, 255, 255, 10);
	glEnable(GL_TEXTURE_2D);
	glBegin(GL_QUADS);      //将图片四个角的位置设置为正交窗口后裁剪面的四个角；
	glTexCoord2d(0.0, 0.0); glVertex3d(-mw_width / 2, 33 - mw_height / 2, -300);
	glTexCoord2d(1.0, 0.0); glVertex3d(mw_width / 2, 33 - mw_height / 2, -300);
	glTexCoord2d(1.0, 1.0); glVertex3d(mw_width / 2, 33 + mw_height / 2, -300);
	glTexCoord2d(0.0, 1.0); glVertex3d(-mw_width / 2, 33 + mw_height / 2, -300);
	glEnd();

	glDisable(GL_TEXTURE_2D);
	glDisable(GL_ALPHA_TEST);
	glEnable(GL_DEPTH_TEST);   //开启深度测试；
}

void MyGLWidget::drawObstacle(int i, GLuint texture, int xrange[][2], int yrange[][2]) {
	if ((cnt[i] + oy[i]) > (300)) {
		cnt[i] = 1;
		//randxy1();
		randxy(ox[i], xrange[i][0], xrange[i][1]);
		randxy(oy[i], yrange[i][0], yrange[i][1]);
		otx[i] = -x;
		oty[i] = -y;
		//printf("ox0:%d oy0:%d\n", ox[0], oy[0]);
	}

	else {
		cnt[i] += (int)ty;
		//printf("cnt0: %d\n",cnt[0]);
	}

	glColor3f(1.f, 1.f, 1.f);
	glDisable(GL_DEPTH_TEST);//关闭深度测试
	GLfloat zh1_width = 1524;
	GLfloat zh1_height = 828;
	glEnable(GL_ALPHA_TEST);//透明部分测试
	glAlphaFunc(GL_GREATER, 0.5);

	glBindTexture(GL_TEXTURE_2D, texture);
	texture_colorkey(255, 255, 255, 10);
	glEnable(GL_TEXTURE_2D);
	glBegin(GL_QUADS);      //将图片四个角的位置设置为正交窗口后裁剪面的四个角；
	glTexCoord2d(0.0, 0.0); glVertex3d(-ox[i] - zh1_width / 2, -zh1_height / 2 + oy[i], -300);
	glTexCoord2d(1.0, 0.0); glVertex3d(-ox[i] + zh1_width / 2, -zh1_height / 2 + oy[i], -300);
	glTexCoord2d(1.0, 1.0); glVertex3d(-ox[i] + zh1_width / 2, +zh1_height / 2 + oy[i], -300);
	glTexCoord2d(0.0, 1.0); glVertex3d(-ox[i] - zh1_width / 2, +zh1_height / 2 + oy[i], -300);
	glEnd();
	glDisable(GL_TEXTURE_2D);

	glDisable(GL_ALPHA_TEST);
	glEnable(GL_DEPTH_TEST);   //开启深度测试；
}

/*###################################################
##  函数: paintGL
##  函数描述： 绘图函数，实现图形绘制，会被update()函数调用
##  参数描述： 无
#####################################################*/

int flag = 0;
void MyGLWidget::paintGL()
{
	GLfloat zoom = 300.f;
	glClear(GL_COLOR_BUFFER_BIT);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-zoom * win_width / win_height, zoom * win_width / win_height, -zoom, zoom, -300.0, 300.0);   //切换为正交视角；
	LoadAllTexture();  //加载各种图片
	glMatrixMode(GL_MODELVIEW);

	glPushMatrix();
	glLoadIdentity();
	if (st->gox !=0) {
		x += st->gox;
	}
	
	glTranslated(x, y+= st->v, 0);
	drawBackground();
	drawBegin();
	glTranslated(otx[0], oty[0], 0);
	drawObstacle(0,Texture[11],xrange,yrange);
	glTranslated(otx[1] - otx[0], oty[1] - oty[0], 0);
	drawObstacle(1, Texture[12], xrange, yrange);
	glTranslated(otx[2] - otx[1], oty[2] - oty[1], 0);
	drawObstacle(2, Texture[13], xrange, yrange);
	glTranslated(otx[3] - otx[2], oty[3] - oty[2], 0);
	drawObstacle(3, Texture[14], xrange, yrange);
	glTranslated(otx[4] - otx[3], oty[4] - oty[3], 0);
	drawObstacle(4, Texture[15], xrange, yrange);
	if (y < 160)
		stagame();
	glPopMatrix();
	//if (isCollision()) printf("Collision\n");
	drawRole();

	glPushMatrix();
	glLoadIdentity();
	glTranslated(240, 250, 0);
	showsc();

	glTranslated(-590, 28, 0);
	Blood();
	glPopMatrix();

	if(y>40) st->score += 10;

	if (st->blood == 0) {
		glPushMatrix();
		glTranslated(-30, 150, 0);
		endgame();
		st->score = 0;
		glPopMatrix();
		timer->stop();
		st->hold = -1;
		//st->death = 1;
	}

	if (st->death != 0) {
		st->death += 1;
		if (st->death > 25) st->death = 0;
	}


	//fail_life();
	if (monster->count < monster->time) {
		st->v = 20;
		monster->count++;
	}
	else {
		if (monster->pos_y != 0) {
			st->fail = 0;
			if (flag == 0) monster->pos_y -= 8;  //未按加速键时怪物的速度
			else {
				monster->pos_y += 4;  //按加速键时怪物的速度
				glPushMatrix();
				glTranslated(0, 70.0f, 20.0f);
				drawSpeed();
				glPopMatrix();
			}
		}
		else st->fail = 1;   //怪物追上人物
		if(!flag) st->v =40;
		if (flag && monster->pos_y > 300 && st->fail==0) {
			monster->count = 0;
			flag = 0;
		}
		else {
			if (st->blood > 0) {
				glPushMatrix();
				glTranslated(monster->pos_x, monster->pos_y, 0.0f);
				drawMonster();
				glPopMatrix();
			}
		}
	}

	if (st->death < 2 || st->blood<=0) {
		if (isCollision()) {
			glPushMatrix();
			glTranslated(0, 40.0f, 0.0f);
			drawFail();
			glPopMatrix();
			timer->stop();
			st->hold = -1;
			if (st->blood > 0) {
				st->blood -= 1; 
				st->death = 1;
			}
			else st->blood = 3;
		}
	}

	if (st->fail == 1) {
		/*glPushMatrix();
		glTranslated(0, 40.0f, 0.0f);
		drawFail();
		glPopMatrix();*/
		if (st->blood > 0) {
			st->blood -= 1;
			st->death = 1;
		}
		else st->blood = 3;
		if (st->blood) {
			timer->stop();
			st->hold = -1;
		}
	}

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45, (float)win_width / win_height, 0.01, 3000);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

}


void MyGLWidget::keyPressEvent(QKeyEvent* e) {

	if (e->key() == Qt::Key_Space) {
		st->hold = -st->hold;
		st->goy = 1;
		if (st->fail == 1) {
			monster->pos_y = 400.0f;
			st->fail = 0;
			monster->count = 0;
		}
	}
	else if (e->key() == Qt::Key_W && st->hold == 1) {
		st->goy = 0;
		st->gox = 0;
	}
	else if (e->key() == Qt::Key_S && st->hold == 1) {
		st->gox = 0;
		st->goy = 1;
	}
	else if (e->key() == Qt::Key_A && st->hold == 1) {
		if (st->gox < 0) {
			st->gox = 0;
		}
		if (st->gox >= 3) {
			st->gox = 4;
		}
		else {
			st->gox += 2;
		}
	}
	else if (e->key() == Qt::Key_D && st->hold == 1) {
		if (st->gox > 0) {
			st->gox = 0;
		}
		if (st->gox <= -3) {
			st->gox = -4;
		}
		else {
			st->gox -= 2;
		}
	}
	else if (e->key() == Qt::Key_F && st->hold == 1) {
		st->v = st->v + 20;
		flag = 1;
	}
	else {
		st->goy = 1;
	}

	if (st->hold==1) {
		timer->start(16);
		if (st->goy == 1) {
				connect(timer, SIGNAL(timeout()), this, SLOT(update()));
		}
		else {
			if (st->gox > 0) {
				timer->start(16);
				connect(timer, SIGNAL(timeout()), this, SLOT(update()));
			}
			else if (st->gox < 0) {
				timer->start(16);
				connect(timer, SIGNAL(timeout()), this, SLOT(update()));
			}
			else {
				timer->stop();
			}

		}
	}
	else if (st->hold==-1) {
		timer->stop();
	}

}


/*###################################################
##  函数: resizeGL
##  函数描述： 当窗口大小改变时调整视窗尺寸
##  参数描述： 无
#####################################################*/
void MyGLWidget::resizeGL(int width, int height)
{
	glViewport(0, 0, width, height);
	ww = width;
	wh = height;
	update();
}

