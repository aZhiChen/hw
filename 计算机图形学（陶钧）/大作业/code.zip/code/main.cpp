#include "myglwidget.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    printf("Press \"Key_2\", the robot moves forward.\n");
    printf("Press \"Key_1\", the robot stands up straight.\n");
    QApplication a(argc, argv);
    MyGLWidget w;
	w.setWindowTitle("2D snow");
    w.show();
    return a.exec();
}
