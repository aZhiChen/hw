#ifndef MYGLWIDGET_H
#define MYGLWIDGET_H

#ifdef MAC_OS
#include <QtOpenGL/QtOpenGL>
#else
#include <GL/glew.h>
#endif
#include <QtGui>
#include <QOpenGLWidget>
#include <QOpenGLFunctions>
struct State {
    int hold;
    int gox;
    int goy;
    int fail;
    int blood;
    int v;
    int death;
    int score;
 };

//����
struct Monster {
    GLfloat pos_x;  //λ��
    GLfloat pos_y;
    int time;  //����ÿ��time֡����
    int count; //�жϹ���count֡
    int i;
    Monster(GLfloat x, GLfloat y,int t,int num,int m_i) {
        pos_x = x;
        pos_y = y;
        time = t;
        count = num;
        i = m_i;
    }
};

class MyGLWidget : public QOpenGLWidget{
    Q_OBJECT

public:
    MyGLWidget(QWidget *parent = nullptr);
    ~MyGLWidget();

protected:
    void initializeGL();
    void paintGL();
    void resizeGL(int width, int height);
    void keyPressEvent(QKeyEvent* e);
    void drawBackground();
    void drawBegin();
    void drawRole();
    void drawMonster();
    void drawFail();
    void drawSpeed();
   // void drawObstacle(int i);
    void showsc();
    void stagame();
    void endgame();
    void Blood();
    void drawObstacle0();
    void drawObstacle1();
    void drawObstacle2();
    void drawObstacle3();
    void drawObstacle4();
    void drawObstacle(int i, GLuint texture, int xrange[][2], int yrange[][2]);
    void randxy(int& num, int max, int min);
    void LoadAllTexture();
    bool isCollision();
    void fail_life();
    
private:
    QTimer *timer;
    bool right_hand;
    bool stand;
    int k;
    int ox[5], oy[5], cnt[5];
    //int ox1, oy1, ox2, oy2, ox3, oy3, otx1, oty1, otx2, oty2;
    int otx[5], oty[5];
    float scrx[5], scry[5];//�ϰ��������Ļ������ֵ
    int xrange[5][2], yrange[5][2];
    float ty;
    GLint Texture[25];
    int ww, wh;
    bool Load, Collision;
    GLfloat x;
    GLfloat y;
    GLfloat z;
    GLint win_width;
    GLint win_height;
    State *st=new State();
    Monster* monster = new Monster(x=0.0f,y=400.0f,50,0,0);

};
#endif // MYGLWIDGET_H
