#ifndef MYGLWIDGET_H
#define MYGLWIDGET_H

#ifdef MAC_OS
#include <QtOpenGL/QtOpenGL>
#else
#include <GL/glew.h>
#endif
#include <QtGui>
#include <QOpenGLWidget>
#include <QOpenGLFunctions_3_3_Core>

class MyGLWidget : public QOpenGLWidget, protected QOpenGLFunctions {
    Q_OBJECT

public:
    MyGLWidget(QWidget *parent = nullptr);
    ~MyGLWidget();

protected:
    void initializeGL();
    void paintGL();
    void resizeGL(int width, int height);
      
    void createSphere(GLfloat* sphere, GLuint longitude, GLuint latitude);                  // 球的顶点生成函数，非索引数组存储方式
    void createSphere2(GLfloat* sphere, GLuint longitude, GLuint latitude);                 // 球的顶点生成函数，索引数组存储方式
    void initShader(const char* vertexPath, const char* fragmentPath, unsigned int* ID);
    void initShaderVariables();
    void DrawWithoutVBO();
    void DrawWithVBO();                    // 使用 vbo 方式绘制
    void DrawUsingOpenGLShading();
    void keyPressEvent(QKeyEvent* e);
    void initVbo();
    void DrawWithIndex();                      // 使用 index array 方式绘制
private:
    QTimer *timer;
    unsigned int program;
    float body;//球体旋转角度
    GLuint vertexShader;//顶点着色器
    GLuint fragmentShader;//片元着色器
    /*
    模式选择
    0：DrawWithoutVBO using phong Shading
    1：GL_FLAT withoutVBO
    2: GL_SMOOTH without VBO
    */
    int mode;
    GLuint vaoId, vboId;
    double TIME;			// 计时
    LARGE_INTEGER t1, t2, tc;
};
#endif // MYGLWIDGET_H
