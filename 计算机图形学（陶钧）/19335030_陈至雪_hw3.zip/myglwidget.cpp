#include "myglwidget.h"
#include<math.h>
#include<iostream>
#include<fstream>
#include<sstream>
#include <QtCore/qdir.h>
#include <qopenglextrafunctions.h>
using namespace std;


#define PI acos(-1) 
#define LATS 1024 //维度划分为512块
#define LONS 1024 // 经度划分为512块
#define R 0.5f //球体半径
//顶点结构
struct Float3 {
	float x, y, z;
};

GLfloat vertices[6 * 3 * LATS * LONS * 2];			//顶点属性组，存放顶点坐标和面法向量
GLuint index[6 * LATS * LONS];						// 索引顶点数组
GLfloat verticesIndex[4 * 3 * LATS * LONS * 2];  	// 顶点属性数组, 存放顶点值和法向量,顶点不重复存储
/*###################################################
##  函数: getPoint
##  函数描述： 输入两个角度，输出球体顶点坐标
##  参数描述：a,b范围在[0,1]
##  parent: 
#####################################################*/
Float3 getPoint(float a, float b) {
	Float3 point;
	point.x = R * sin(PI * a) * cos(2 * PI * b);
	point.z = R * sin(PI * a) * sin(2 * PI * b);
	point.y = R * cos(PI * a);
	return point;
}


/*###################################################
##  函数: MyGLWidget
##  函数描述： MyGLWidget类的构造函数，实例化定时器timer
##  参数描述：
##  parent: MyGLWidget的父对象
#####################################################*/
MyGLWidget::MyGLWidget(QWidget *parent)
	:QOpenGLWidget(parent)
{
	timer = new QTimer(this); // 实例化一个定时器
	timer->start(16); // 时间间隔设置为16ms，可以根据需要调整
	connect(timer, SIGNAL(timeout()), this, SLOT(update())); // 连接update()函数，每16ms触发一次update()函数进行重新绘图

	
}


/*###################################################
##  函数: ~MyGLWidget
##  函数描述： ~MyGLWidget类的析构函数，删除timer
##  参数描述： 无
#####################################################*/
MyGLWidget::~MyGLWidget()
{
	delete this->timer;

	glDetachShader(program, vertexShader);
	glDetachShader(program, fragmentShader);
	glDeleteProgram(program);
}



/*###################################################
##  函数: paintGL
##  函数描述： 绘图函数，实现图形绘制，会被update()函数调用
##  参数描述： 无
#####################################################*/
void MyGLWidget::paintGL()
{
	// Your Implementation

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClearColor(1.0, 1.0, 1.0, 0.0);			// 黑屏

	if (mode == 1) {
		//glUseProgram(0);
		//glPushMatrix();
		glShadeModel(GL_FLAT);
		DrawUsingOpenGLShading();
		//glPopMatrix();
	}
	if (mode == 2) {
		//glUseProgram(0);
		//glPushMatrix();
		glShadeModel(GL_SMOOTH);
		DrawUsingOpenGLShading();
		//glPopMatrix();
	}
	if (mode == 3) {
		DrawWithVBO();
	}
	if (mode == 4) {
		DrawWithIndex();
	}
	
	if (mode == 0) {
		glPushMatrix();
		initShader("PhongVertexShader.vert", "PhongFragmentShader.frag", &program);
		DrawWithoutVBO();
		glPopMatrix();
	}

	
}

/*###################################################
##  函数: keyPressEvent
##  函数描述： 键盘交互，输入数字，切换mode
##  参数描述： 无
#####################################################*/
void MyGLWidget::keyPressEvent(QKeyEvent* e) {
	if (e->key() == Qt::Key_2) {
		mode = 2;
		update();
	}
	else if (e->key() == Qt::Key_1) {
		mode = 1;
		update();
	}
	else if (e->key() == Qt::Key_0) {
		mode = 0;
		update();
	}
	else if (e->key() == Qt::Key_4) {
		mode = 4;
		update();
	}
	else if (e->key() == Qt::Key_3) {
		mode = 3;
		update();
	}
}

/*###################################################
##  函数: resizeGL
##  函数描述： 当窗口大小改变时调整视窗尺寸
##  参数描述： 无
#####################################################*/
void MyGLWidget::resizeGL(int width, int height)
{
	glViewport(0, 0, width, height);
	update();
}


/*###################################################
##  函数: computeNormal
##  函数描述： 计算面法向量
##  参数描述：point1：顶点1
##			  point3：顶点2
##			  point4：顶点3	
##			  n：法向量
##  parent: MyGLWidget的父对象
#####################################################*/
void computeNormal(Float3 point1, Float3 point4, Float3 point3, Float3 &n) {
	//Float3 n;
	float nlength;
	float vecx[2], vecy[2], vecz[2];
	vecx[0] = point1.x - point4.x;
	vecy[0] = point1.y - point4.y;
	vecz[0] = point1.z - point4.z;

	vecx[1] = point1.x - point3.x;
	vecy[1] = point1.y - point3.y;
	vecz[1] = point1.z - point3.z;
			
	n.x = vecy[0] * vecz[1] - vecy[1] * vecz[0];
	n.y = vecx[1] * vecz[0] - vecx[0] * vecz[1];
	n.z = vecx[0] * vecy[1] - vecx[1] * vecy[0];

	nlength = sqrt(pow(n.x, 2) + pow(n.y, 2) + pow(n.z, 2));

	n.x = n.x / nlength;
	n.y = n.y / nlength;
	n.z = n.z / nlength;
}

/*###################################################
##  函数: saveMessage
##  函数描述： 存储顶点信息和法向量信息至数组
##  参数描述：point1：顶点1
##			  point3：顶点2
##			  point4：顶点3
##			  n：法向量
##  parent: MyGLWidget的父对象
#####################################################*/
void saveMessage(Float3 point1, Float3 point2, Float3 point3, Float3 n, int& offset, GLfloat* sphere){
	memcpy(sphere + offset, &point1, sizeof(Float3));
	offset += 3;
	memcpy(sphere + offset, &n, sizeof(Float3));
	offset += 3;
	memcpy(sphere + offset, &point2, sizeof(Float3));
	offset += 3;
	memcpy(sphere + offset, &n, sizeof(Float3));
	offset += 3;
	memcpy(sphere + offset, &point3, sizeof(Float3));
	offset += 3;
	memcpy(sphere + offset, &n, sizeof(Float3));
	offset += 3;
}
 

/*###################################################
##  函数: createSphere
##  函数描述： 创建球的顶点属性
##  参数描述：sphere存储顶点属性和法向量
##				longitude：经度细分粒度
##				latitude：纬度细分粒度			
##  parent: MyGLWidget的父对象
#####################################################*/
void MyGLWidget::createSphere(GLfloat* sphere, GLuint longitude, GLuint latitude) {
	GLfloat perLon = 1.0f / longitude;
	GLfloat perLat = 1.0f / latitude;
	GLint offset = 0;
	Float3 point1, point2, point3, point4;
	Float3 nvec;

	for (int lat = 0; lat < latitude; lat++) {
		for (int lon = 0; lon < longitude; lon++) {
			//一次得到4个顶点，生成两个三角形
			point1 = getPoint(lat * perLat, lon * perLon);
			point2 = getPoint((lat + 1) * perLat, lon * perLon);
			point3 = getPoint((lat + 1) * perLat, (lon + 1) * perLon);
			point4 = getPoint(lat * perLat, (lon + 1) * perLon);

			//计算第一个三角形的面法向量
			computeNormal(point1, point4, point3, nvec);
			
			//存储顶点信息和法向量信息
			saveMessage(point1, point4, point3, nvec, offset, sphere);

			//计算第二个三角形的面法向量
			computeNormal(point1, point3, point2, nvec);

			//存储顶点信息和法向量信息
			saveMessage(point1, point3, point2, nvec, offset, sphere);

		}
	}
}



/*###################################################
##  函数: createSphere2
##  函数描述： 创建球的顶点属性，顶点不重复存储
##  参数描述：
##  	sphere: 球的顶点属性存放地址
##  	longitude: 经度细分程度
##		latitude: 纬度细分程度
#####################################################*/
void MyGLWidget::createSphere2(GLfloat* sphere, GLuint longitude, GLuint latitude) {
	GLfloat lon_step = 1.0f / longitude;		// 经度细分
	GLfloat lat_step = 1.0f / latitude;			// 纬度细分
	GLuint offset = 0;							// 顶点数组偏移量
	GLuint indexOffset = 0;
	Float3 point1, point2, point3, point4;
	Float3 nvec;
	float vec1[3], vec2[3], vec3[3];
	float D;

	for (int lat = 0; lat < latitude; lat++) {
		for (int lon = 0; lon < longitude; lon++) {
			// 一次得到四个点,生成两个三角形
			point1 = getPoint(lat * lat_step, lon * lon_step);
			point2 = getPoint((lat + 1) * lat_step, lon * lon_step);
			point3 = getPoint((lat + 1) * lat_step, (lon + 1) * lon_step);
			point4 = getPoint(lat * lat_step, (lon + 1) * lon_step);

			// 计算第三角形的顶点的法向量
			//计算第一个三角形的面法向量
			computeNormal(point1, point4, point3, nvec);

			// 1 4 3、 1 3 2
			index[indexOffset] = offset / 6 + 1 - 1;
			indexOffset++;
			index[indexOffset] = offset / 6 + 4 - 1;
			indexOffset++;
			index[indexOffset] = offset / 6 + 3 - 1;
			indexOffset++;

			index[indexOffset] = offset / 6 + 1 - 1;
			indexOffset++;
			index[indexOffset] = offset / 6 + 3 - 1;
			indexOffset++;
			index[indexOffset] = offset / 6 + 2 - 1;
			indexOffset++;


			// 存储 4 个顶点的位置和法向量
			memcpy(sphere + offset, &point1, sizeof(Float3));
			offset += 3;
			memcpy(sphere + offset, &nvec, sizeof(Float3));
			offset += 3;
			memcpy(sphere + offset, &point2, sizeof(Float3));
			offset += 3;
			memcpy(sphere + offset, &nvec, sizeof(Float3));
			offset += 3;
			memcpy(sphere + offset, &point3, sizeof(Float3));
			offset += 3;
			memcpy(sphere + offset, &nvec, sizeof(Float3));
			offset += 3;
			memcpy(sphere + offset, &point4, sizeof(Float3));
			offset += 3;
			memcpy(sphere + offset, &nvec , sizeof(Float3));
			offset += 3;

		}
	}
}




/*###################################################
##  函数: initShader
##  函数描述： 初始化Shader,加载到内存，编译链接
##  参数描述：
##  	vertexPath:	顶点着色器相对于该文件的路径
##		fragmentPath: 片元着色器相对于该文件的路径
## 		ID: program ID
#####################################################*/
void  MyGLWidget::initShader(const char* vertexPath, const char* fragmentPath, unsigned int* ID) {
	string vertexCode;
	string fragmentCode;
	ifstream vertexShaderFile;
	ifstream fragmentShaderFile;
	stringstream vertexStream;
	stringstream fragmentStream;
	const char* vertexShaderSource;
	const char* fragmentShaderSource;

	// 将相对路径转化成绝对路径
	string vertexDir = QDir::currentPath().toStdString() + "/" + vertexPath;
	string fragmentDir = QDir::currentPath().toStdString() + "/" + fragmentPath;

	//加载顶点着色器代码
	vertexShaderFile.open(vertexDir);
	vertexStream << vertexShaderFile.rdbuf();
	vertexShaderFile.close();

	//加载片元着色器代码
	fragmentShaderFile.open(fragmentDir);
	fragmentStream << fragmentShaderFile.rdbuf();
	fragmentShaderFile.close();

	//字符转换
	vertexCode = vertexStream.str();
	fragmentCode = fragmentStream.str();
	vertexShaderSource = vertexCode.c_str();
	fragmentShaderSource = fragmentCode.c_str();

	//编译顶点着色器，在控制台输出LOG
	int success;
	char infoLog[512];
	//创建顶点着色器对象
	vertexShader = glCreateShader(GL_VERTEX_SHADER);
	//将代码链接到着色器对象
	glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
	//编译着色器对象
	glCompileShader(vertexShader);
	//查看顶点着色器是否编译成功
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(vertexShader, 512, NULL, infoLog);
		cout << "error in vertexshader: compilation failed\n" << infoLog << endl;
	}
	else
		//cout << "vertshader compiled successfully" << endl;

	//编译片元着色器，在控制台输出LOG
	fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
	glCompileShader(fragmentShader);
	glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(fragmentShader, 512, NULL, infoLog);
		cout << "error in fragmentshader: compilation failed\n" << infoLog << endl;
	}
	else
		//cout << "fragmentshader compiled successfully" << endl;

	//绑定并链接着色器
	//创建一个program对象
	*ID = glCreateProgram();
	//将编译后的着色器对象链接到程序对象
	glAttachShader(*ID, vertexShader);
	glAttachShader(*ID, fragmentShader);
	//链接程序对象
	glLinkProgram(*ID);
	//查看是否链接成功
	glGetProgramiv(*ID, GL_LINK_STATUS, &success);
	if (!success)
	{
		glGetProgramInfoLog(*ID, 512, NULL, infoLog);
		cout << "error: link failed\n" << infoLog << endl;
	}
	else
		//cout << "link successfully" << endl;
	//删除着色器对象
	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);

	if(mode == 3)
		initVbo();
	initShaderVariables();

}

/*###################################################
##  函数: initShaderVariables
##  函数描述： 初始化着色器参数
##  参数描述：无
#####################################################*/
void MyGLWidget::initShaderVariables() {
	glUseProgram(program);
	float mat[16];

	//设置shader参数
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslatef(0.0f, 0.0f, -10.0f);			// 将球初始位置置于沿 z 轴负方向平移 10 个单位
	//printf("body is %f\n",body);
	glRotatef(body, 0, 1, 0);				// 绕 y 轴顺时针旋转 body°
	glTranslatef(0.0f, 0.0f, 1.0f);			// 设置球的旋转半径
	glGetFloatv(GL_MODELVIEW_MATRIX, mat);
	glUniformMatrix4fv(glGetUniformLocation(program, "model"), 1, GL_FALSE, mat);
	glLoadIdentity();
	glGetFloatv(GL_MODELVIEW_MATRIX, mat);
	glUniformMatrix4fv(glGetUniformLocation(program, "view"), 1, GL_FALSE, mat);
	// 投影变换
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(30.0f, width() / height(), 0.1f, 1000.0f);		// 放置摄像机
	glGetFloatv(GL_PROJECTION_MATRIX, mat);
	glUniformMatrix4fv(glGetUniformLocation(program, "projection"), 1, GL_FALSE, mat);
	glUniform1i(glGetUniformLocation(program, "mode"), 1);
	//glUniform1i(glGetUniformLocation(program, "twisting"), angle);
}

/*###################################################
##  函数: DrawUsingOpenGLShading
##  函数描述：使用OpenGL自带的flat与smooth shading,不使用 vbo 方式绘制
##  参数描述：无
#####################################################*/
void MyGLWidget::DrawUsingOpenGLShading() {
	int localLATS = 28;
	int localLONS = 28;
	GLfloat perLon = 1.0f / localLONS;
	GLfloat perLat = 1.0f / localLATS;
	Float3 point1, point2, point3, point4;
	glBegin(GL_QUADS);
	
	for (int lat = 0; lat < localLATS; lat++) {
		for (int lon = 0; lon < localLONS; lon++) {
			//一次得到4个顶点，生成两个三角形
			point1 = getPoint(lat * perLat, lon * perLon);
			point2 = getPoint((lat + 1) * perLat, lon * perLon);
			point3 = getPoint((lat + 1) * perLat, (lon + 1) * perLon);
			point4 = getPoint(lat * perLat, (lon + 1) * perLon);
			//glColor3f(0.5, 1.0, 1.0);
			glColor3f((lat* localLATS +lon) * 0.001, (lat * localLATS + lon) * 0.002, (lat * localLATS + lon) * 0.003);
			glVertex3f(point1.x, point1.y, point1.z);
			glColor3f(((lat+1) * localLATS + lon) * 0.001, ((lat+1) * localLATS + lon) * 0.002, ((lat+1) * localLATS + lon) * 0.003);
			glVertex3f(point2.x, point2.y, point2.z);
			glColor3f(((lat + 1) * localLATS + lon + 1) * 0.001, ((lat + 1) * localLATS + lon + 1) * 0.002, ((lat + 1) * localLATS + lon + 1) * 0.003);
			glVertex3f(point3.x, point3.y, point3.z);
			glColor3f((lat * localLATS + lon + 1) * 0.001, (lat * localLATS + lon + 1) * 0.002, (lat * localLATS + lon + 1) * 0.003);
			glVertex3f(point4.x, point4.y, point4.z);
		}
	}
	glEnd();

	body += 1.0f;
}

/*###################################################
##  函数: DrawWithoutVBO
##  函数描述： 不使用 vbo 方式绘制
##  参数描述：无
#####################################################*/
void MyGLWidget::DrawWithoutVBO() {
	QueryPerformanceFrequency(&tc);
	QueryPerformanceCounter(&t1);

	glBegin(GL_TRIANGLES);
	for (int i = 0; i < 6 * 3 * LATS * LONS * 2; i = i + 6) {
		glVertex3f(vertices[i], vertices[i + 1], vertices[i + 2]);//顶点
		glNormal3f(vertices[i + 3], vertices[i + 4], vertices[i + 5]);//法向量
	}
	glEnd();


	QueryPerformanceCounter(&t2);
	TIME = (double)(t2.QuadPart - t1.QuadPart) * 1.0 / (double)tc.QuadPart;

	if (body == 0)
		printf("TimeConsume : %.4fs\n", TIME);
	
	body += 1.0f;
		
}


/*###################################################
##  函数: DrawWithVBO
##  函数描述： 使用 vbo 方式绘制
##  参数描述：无
#####################################################*/
void MyGLWidget::DrawWithVBO() {
	QueryPerformanceFrequency(&tc);
	QueryPerformanceCounter(&t1);

	// 开始绘制物体
	glPushMatrix();
	glBindVertexArray(vaoId);
	glDrawArrays(GL_TRIANGLES, 0, 6 * LATS  * LONS);
	glBindVertexArray(0);
	glPopMatrix();

	QueryPerformanceCounter(&t2);
	TIME = (double)(t2.QuadPart - t1.QuadPart) * 1.0 / (double)tc.QuadPart;

	if (body == 0)
		printf("TimeConsume : %.4fs\n", TIME);

	body += 1.0f;
}

/*###################################################
##  函数: initVboVao
##  函数描述： 初始化顶点缓冲区与顶点缓冲数组配置
##  参数描述：无
#####################################################*/
void MyGLWidget::initVbo() {
	// 创建物体的 VAO
	//创建并绑定相应功能指针
	glGenVertexArrays(1, &vaoId);
	//创建VBO
	glGenBuffers(1, &vboId);

	//绑定VBO
	glBindBuffer(GL_ARRAY_BUFFER, vboId);
	//将数据拷贝至VBO
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	//设置顶点属性指针
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);

	// 设置法向量属性
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GL_FLOAT)));
	glEnableVertexAttribArray(1);

	
	//解绑VAO
	glBindVertexArray(0);
}

/*###################################################
##  函数: DrawIndex
##  函数描述： 使用 index array 方式进行绘制
##  参数描述：无
#####################################################*/
void MyGLWidget::DrawWithIndex() {
	glEnableClientState(GL_NORMAL_ARRAY);		// 启用法线数组
	glEnableClientState(GL_VERTEX_ARRAY);		// 启用顶点数组
	glNormalPointer(GL_FLOAT, 6 * sizeof(GLfloat), verticesIndex + 3);	// 指定法线数组
	glVertexPointer(3, GL_FLOAT, 6 * sizeof(GLfloat), verticesIndex);	// 指定顶点数组

	QueryPerformanceFrequency(&tc);
	QueryPerformanceCounter(&t1);

	glPushMatrix();
	glDrawElements(GL_TRIANGLES, 6 * LATS * LONS, GL_UNSIGNED_INT, index);	// 绘制图形
	glPopMatrix();

	QueryPerformanceCounter(&t2);
	TIME = (double)(t2.QuadPart - t1.QuadPart) * 1.0 / (double)tc.QuadPart;

	if (body == 0)
		printf("TimeConsume : %.4fs\n", TIME);

	glDisableClientState(GL_VERTEX_ARRAY);  // 关闭数组
	glDisableClientState(GL_NORMAL_ARRAY);

	body += 1.0f;
}


/*###################################################
##  函数: initializeGL
##  函数描述： 初始化绘图参数，如视窗大小、背景色等
##  参数描述： 无
#####################################################*/
void MyGLWidget::initializeGL()
{
	initializeOpenGLFunctions();

	// vertexShader = glCreateShader(GL_VERTEX_SHADER);
	// Your Implementation

	glViewport(0, 0, width(), height());
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	printf("Please enter number to choose a mode.\n");
	printf("Enter 0 to choose DrawWithoutVBO using phong Shading.\n");
	printf("Enter 1 to choose GL_FLAT withoutVBO.\n");
	printf("Enter 2 to choose GL_SMOOTH withoutVBO.\n");
	printf("Enter 3 to choose DrawWithVBO.\n");
	printf("Enter 4 to choose DrawWithIndex.\n");
	createSphere(vertices, LONS, LATS);
	program = 3;
	mode = -1;
	body = 0.0f;
} 

