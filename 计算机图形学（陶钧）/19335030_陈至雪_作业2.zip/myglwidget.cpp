#include "myglwidget.h"

/*###################################################
##  函数: MyGLWidget
##  函数描述： MyGLWidget类的构造函数，实例化定时器timer
##  参数描述：
##  parent: MyGLWidget的父对象
#####################################################*/

MyGLWidget::MyGLWidget(QWidget *parent)
	:QOpenGLWidget(parent)
{
	k = 0;
	stand = true;
	right_hand = true;
	timer = new QTimer(this); // 实例化一个定时器
	timer->start(16); // 时间间隔设置为16ms，可以根据需要调整
	connect(timer, SIGNAL(timeout()), this, SLOT(update())); // 连接update()函数，每16ms触发一次update()函数进行重新绘图
}


/*###################################################
##  函数: ~MyGLWidget
##  函数描述： ~MyGLWidget类的析构函数，删除timer
##  参数描述： 无
#####################################################*/
MyGLWidget::~MyGLWidget()
{
	delete this->timer;
}


/*###################################################
##  函数: initializeGL
##  函数描述： 初始化绘图参数，如视窗大小、背景色等
##  参数描述： 无
#####################################################*/
void MyGLWidget::initializeGL()
{
	glViewport(0, 0, width(), height());  
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f); 
	glDisable(GL_DEPTH_TEST);             
}

/*###################################################
##  函数: paintGL
##  函数描述： 绘图函数，实现图形绘制，会被update()函数调用
##  参数描述： 
#####################################################*/

void MyGLWidget::drawUnitBox(GLfloat x, GLfloat y, GLfloat z){
	glBegin(GL_TRIANGLE_STRIP);
	GLfloat x1 = 0.5 * x;
	GLfloat y1 = 0.5 * y;
	GLfloat z1 = 0.5 * z;
	glVertex3f(-x1,y1,-z1);
	glVertex3f(x1, y1, -z1);
	glVertex3f(-x1,-y1, -z1);
	glVertex3f(x1, -y1, -z1);
	glVertex3f(x1, -y1, z1);
	glVertex3f(x1, y1, -z1);
	glVertex3f(x1, y1, z1);
	glVertex3f(-x1, y1, -z1);
	glVertex3f(-x1, y1, z1);
	glVertex3f(-x1, -y1, -z1);
	glVertex3f(-x1, -y1, z1);
	glVertex3f(x1, -y1, z1);
	glVertex3f(-x1, y1, z1);
	glVertex3f(x1, y1, z1);

	glEnd();
}


void MyGLWidget::drawRobot() {
	//画帽子
	glPushMatrix();
	glTranslatef(0.0f, 28.0f, 0.0f);
	glScalef(7.0f, 2.0f, 6.0f);
	glColor4f(0.2f, 0.5f, 0.9f, 0.5f);
	drawUnitBox(1.0f, 1.0f, 1.0f);
	glPopMatrix();
	
	//画头
	glPushMatrix();
	glTranslatef(0.0f,25.0f,0.0f);
	glScalef(5.0f,5.0f,5.0f);
	glColor4f(1.5f,0.5f,0.8f,0.5f);
	drawUnitBox(1.0f,1.0f,1.0f);
	glPopMatrix();

	if (!stand) {
		//画左手臂
		glPushMatrix();
		glTranslatef(-5.5f, 15.5f, 0.0f);
		glTranslatef(0.0f, 6.5f, 0.0f);
		if (!right_hand) {
			glRotatef(-20.0f, 1.0, 0.0, 0.0);
			glTranslatef(0.0f, -6.5f, 0.0f);
		}
		else {
			glRotatef(20.0f, 1.0, 0.0, 0.0);
			glTranslatef(0.0f, -6.5f, 0.0f);
		}
		glScalef(2.0f, 13.0f, 2.0f);
		glColor4f(1.5f, 0.5f, 0.8f, 0.5f);
		drawUnitBox(1.0f, 1.0f, 1.0f);
		glPopMatrix();

		//画身体
		glPushMatrix();
		glTranslatef(0.0f, 17.0f, 0.0f);
		glScalef(8.0f, 10.0f, 5.0f);
		glColor4f(0.5f, 0.5f, 0.8f, 0.5f);
		drawUnitBox(1.0f, 1.0f, 1.0f);
		glPopMatrix();

		//画右手臂
		glPushMatrix();
		glTranslatef(5.5f, 15.5f, 0.0f);
		glTranslatef(0.0f, 6.5f, 0.0f);
		if (right_hand) {
			glRotatef(-20.0f, 1.0, 0.0, 0.0);
			glTranslatef(0.0f, -6.5f, 0.0f);
		}
		else {
			glRotatef(20.0f, 1.0, 0.0, 0.0);
			glTranslatef(0.0f, -6.5f, 0.0f);
		}
		glScalef(2.0f, 13.0f, 2.0f);
		glColor4f(0.8f, 0.5f, 0.8f, 0.5f);
		drawUnitBox(1.0f, 1.0f, 1.0f);
		glPopMatrix();

		//左小腿
		glPushMatrix();
		glTranslatef(-1.5f, -0.5f, 0.0f);
		glTranslatef(0.0f, 3.5f, 0.0f);
		if (!right_hand) {
			glRotatef(45.0f, 1.0, 0.0, 0.0);
			glTranslatef(0.0f, -3.5f, 0.0f);
		}
		else {
			glRotatef(0.0f, 1.0, 0.0, 0.0);
			glTranslatef(0.0f, -2.42f, 4.0f);
		}
		glScalef(2.0f, 7.5f, 2.0f);
		glColor4f(1.5f, 0.5f, 0.8f, 0.5f);
		drawUnitBox(1.0f, 1.0f, 1.0f);
		glPopMatrix();

		//右小腿
		glPushMatrix();
		glTranslatef(1.5f, -0.5f, 0.0f);
		glTranslatef(0.0f, 3.5f, 0.0f);
		if (!right_hand) {
			glRotatef(0.0f, 1.0, 0.0, 0.0);
			glTranslatef(0.0f, -2.42f, 4.0f);
		}
		else {
			glRotatef(45.0f, 1.0, 0.0, 0.0);
			glTranslatef(0.0f, -3.5f, 0.0f);
		}
		glScalef(2.0f, 7.5f, 2.0f);
		glColor4f(0.8f, 0.5f, 0.8f, 0.5f);
		drawUnitBox(1.0f, 1.0f, 1.0f);
		glPopMatrix();

		//左大腿
		glPushMatrix();
		glTranslatef(-1.5f, 7.0f, 0.0f);
		glTranslatef(0.0f, 4.0f, 0.0f);
		if (!right_hand) {
			glRotatef(0.0f, 1.0, 0.0, 0.0);
			glTranslatef(0.0f, -4.0f, 0.0f);
		}
		else {
			glRotatef(-30.0f, 1.0, 0.0, 0.0);
			glTranslatef(0.0f, -4.0f, 0.0f);
		}
		glScalef(2.0f, 8.0f, 2.0f);
		glColor4f(1.5f, 0.5f, 0.8f, 0.5f);
		drawUnitBox(1.0f, 1.0f, 1.0f);
		glPopMatrix();


		//右大腿
		glPushMatrix();
		glTranslatef(1.5f, 7.0f, 0.0f);
		glTranslatef(0.0f, 4.0f, 0.0f);
		if (!right_hand) {
			glRotatef(-30.0f, 1.0, 0.0, 0.0);
			glTranslatef(0.0f, -4.0f, 0.0f);
		}
		else {
			glRotatef(0.0f, 1.0, 0.0, 0.0);
			glTranslatef(0.0f, -4.0f, 0.0f);
		}
		glScalef(2.0f, 8.0f, 2.0f);
		glColor4f(0.8f, 0.5f, 0.8f, 0.5f);
		drawUnitBox(1.0f, 1.0f, 1.0f);
		glPopMatrix();
	}

	else {
		//站立时左手臂
		glPushMatrix();
		glTranslatef(-5.5f, 15.5f, 0.0f);
		glScalef(2.0f, 13.0f, 2.0f);
		glColor4f(1.5f, 0.5f, 0.8f, 0.5f);
		drawUnitBox(1.0f, 1.0f, 1.0f);
		glPopMatrix();

		//画身体
		glPushMatrix();
		glTranslatef(0.0f, 17.0f, 0.0f);
		glScalef(8.0f, 10.0f, 5.0f);
		glColor4f(0.5f, 0.5f, 0.8f, 0.5f);
		drawUnitBox(1.0f, 1.0f, 1.0f);
		glPopMatrix();

		//站立时右手臂
		glPushMatrix();
		glTranslatef(5.5f, 15.5f, 0.0f);
		glScalef(2.0f, 13.0f, 2.0f);
		glColor4f(0.8f, 0.5f, 0.8f, 0.5f);
		drawUnitBox(1.0f, 1.0f, 1.0f);
		glPopMatrix();


		//站立时左腿
		glPushMatrix();
		glTranslatef(-1.5f, 3.0f, 0.0f);
		glScalef(2.0f, 16.0f, 2.0f);
		glColor4f(1.5f, 0.5f, 0.8f, 0.5f);
		drawUnitBox(1.0f, 1.0f, 1.0f);
		glPopMatrix();


		//站立时右腿
		glPushMatrix();
		glTranslatef(1.5f, 3.0f, 0.0f);
		glScalef(2.0f, 16.0f, 2.0f);
		glColor4f(0.8f, 0.5f, 0.8f, 0.5f);
		drawUnitBox(1.0f, 1.0f, 1.0f);
		glPopMatrix();
	}
}


void MyGLWidget::runRobot() {
	glPushMatrix();
	//防止溢出
	if (k > 3600) {
		k -=  3600;
	}
	GLfloat r = (k * 9.55);
	glRotatef(-r, 0.0, 1.0, 0.0);
	glTranslatef(30.0f, 0.0f, 0.0f);
	drawRobot();
	glPopMatrix();
}

void MyGLWidget::drawBackground() {
	for (int i = 0; i < 120; i++) {
		GLfloat a = 3.0 * i;
		glPushMatrix();
		glRotatef(a, 0.0f, 1.0f, 0.0f);
		glTranslatef(30.0f, -3.0f, 0.0f);
		glScalef(10.0f, 5.0f, 2.0f);
		glColor4f(0.5f, 1.8f, 1.5f, 0.5f);
		drawUnitBox(1.0f, 1.0f, 1.0f);
		glPopMatrix();
	}
}

/*###################################################
##  函数: paintGL
##  函数描述： 绘图函数，实现图形绘制，会被update()函数调用
##  参数描述： 无
#####################################################*/
void MyGLWidget::paintGL()
{
	// Your Implementation
	//glClearColor(0.0f, 0.0f, 0.0f, 0.0f); //设置清理色为黑色
	glClear(GL_COLOR_BUFFER_BIT);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	glOrtho(-80.0f, 80.0f, -100.0f, 100.0f, -80.0f, 80.0f);
	gluLookAt(-10.0f, 10.0f, 10.0f,//相机的位置
		0.0f, 0.0f, 0.0f,//镜头对准的物体在世界坐标的位置
		0.0f, 1.0f, 0.0f);//相机向上的方向在世界坐标中的方向

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	drawBackground();
	runRobot();
	
	//drawRobot();

}


void MyGLWidget::keyPressEvent(QKeyEvent* e) {
	//Press 0 or 1 to switch the scene
	if (e->key() == Qt::Key_2) {
		stand = false;
		k += 1;
		if (right_hand) {
			right_hand = false;
		}
		else {
			right_hand = true;
		}
		update();
	}
	else if (e->key() == Qt::Key_1) {
		//scene_id = 1;
		//right_hand = false;
		stand = true;
		update();
	}
}


/*###################################################
##  函数: resizeGL
##  函数描述： 当窗口大小改变时调整视窗尺寸
##  参数描述： 无
#####################################################*/
void MyGLWidget::resizeGL(int width, int height)
{
	glViewport(0, 0, width, height);
	
	update();
}

