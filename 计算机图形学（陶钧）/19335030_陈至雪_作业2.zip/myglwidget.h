#ifndef MYGLWIDGET_H
#define MYGLWIDGET_H

#ifdef MAC_OS
#include <QtOpenGL/QtOpenGL>
#else
#include <GL/glew.h>
#endif
#include <QtGui>
#include <QOpenGLWidget>
#include <QOpenGLFunctions>
 
class MyGLWidget : public QOpenGLWidget{
    Q_OBJECT

public:
    MyGLWidget(QWidget *parent = nullptr);
    ~MyGLWidget();

protected:
    void initializeGL();
    void paintGL();
    void resizeGL(int width, int height);
    void keyPressEvent(QKeyEvent* e);
    void drawRobot();
    void drawUnitBox(GLfloat x, GLfloat y, GLfloat z);
    void runRobot();
    void drawBackground();
private:
    QTimer *timer;
    bool right_hand;
    bool stand;
    int k;
};
#endif // MYGLWIDGET_H
